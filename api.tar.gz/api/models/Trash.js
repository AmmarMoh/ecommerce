
module.exports = {

  attributes: {
  	user_id:{
  		type: 'string',
  		primaryKey: true,
  		required:true,
  		unique: true
  	}
  }
};