/**
 * MessagesController
 *
 * @description :: Server-side logic for managing Messages
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */


var async = require("async");

module.exports = {
	
	inbox: function(req, res){
		if(req.method != 'GET'){
			return res.forbidden(Response.failure("Method Not Allowed", 405));
		}

		AuthFunctions.getUser(req.headers['authorization'], function(data){
			if(data == 'bad') return res.serverError(Response.failure("Not Authorized", 401));
			var uid = data.id;
			var data_return
			Inbox.findOrCreate({user_id:uid}, {user_id:uid}, function(err, created){
				if(!err && created){
					Thread.find({box:uid, trash:0}, function(err, finded){
						if(!err && finded){
							return res.ok(Response.success(finded))	
						} else{
							return res.serverError(Response.failure(err, 500));		
						}
						
					})
				} else{
					return res.serverError(Response.failure(err, 500));
				}
			})
		})

	},

	thread: function(req, res){
		if(req.method != 'GET'){
			return res.forbidden(Response.failure("Method Not Allowed", 405));
		}

		AuthFunctions.getUser(req.headers['authorization'], function(data){
			if(data == 'bad') return res.serverError(Response.failure("Not Authorized", 401)); 
			var uid = data.id;
			if(!req.query.identifier) return res.serverError(Response.failure("Bad Request", 400)); 
			Message.find({thread_identifier:req.query.identifier}, function(err, created){
				if(!err && created){
					return res.ok(Response.success(created));
				} else{
					return res.serverError(Response.failure(err, 500));
				}
			})
		})

	},

	trash: function(req,res){
		if(req.method != 'GET'){
			return res.forbidden(Response.failure("Method Not Allowed", 405));
		}

		AuthFunctions.getUser(req.headers['authorization'], function(data){
			if(data == 'bad') return res.serverError(Response.failure("Not Authorized", 401)); 
			var uid = data.id;

			Inbox.findOrCreate({user_id:uid}, {user_id:uid}, function(err, created){
				if(!err && created){
					Thread.find({box:uid, trash:1}, function(err, finded){
						if(!err && finded){
							return res.ok(Response.success(finded))	
						} else{
							return res.serverError(Response.failure(err, 500));		
						}
						
					})
				} else{
					return res.serverError(Response.failure(err, 500));
				}
			})
		})
	},

	send: function(req, res){
		if(req.method != 'POST'){
			return res.forbidden(Response.failure("Method Not Allowed", "405"));
		}
		AuthFunctions.getUser(req.headers['authorization'], function(data){
			if(data == 'bad') return res.serverError(Response.failure("Not Authorized", 401));
			var fn = {
				createMultiThreads: function(body, users, callback){
				var data_return = {};
				for(var i = 0; i< users.length; i++){
					Inbox.findOrCreate({user_id:users[i].id}, {user_id:users[i].id}, function(err, created){
						if(!err && created){
							Thread.findOrCreate({identifier:body.identifier}, {identifier:body.identifier, title:body.title, box:created.user_id, receivers:body.receivers},  function(err, created){
								if(err){
									return res.serverError(Response.failure(err, 500));
								}
								data_return = {
									createdAt : created.createdAt,
									title : created.title
								}
							})
						}
					})

				}

				callback(data_return);

				}
			
			} 
			var thread_createdAt, thread_title;
			var uid = data.id;
			var body = req.body;
			body.sender = {
				username: data.name.display,
				id : uid
			};
			var users = body.receivers;
			if(!body.identifier){
				body.identifier = Math.random().toString(36).substr(2,15);
			}
			

			async.each(users, function(user, callback){
				Inbox.findOrCreate({user_id:user.id}, {user_id:user.id}, function(err, created){
					if(!err && created){
						Thread.findOrCreate({identifier:body.identifier}, {identifier:body.identifier, title:body.title, box:created.user_id, receivers:body.receivers},  function(err, created){
							if(err){
								return res.serverError(Response.failure(err, 500));
							}
							console.log(created.createdAt);
							thread_createdAt = created.createdAt;
							thread_title = created.title;
							callback(null);
						})
					}
				})
			}, function(err){
				if(err){
					return res.serverError(Response.failure(err, 500));
				}
				console.log("skadklsadj");
				console.log(thread_createdAt);
				Message.create({thread_identifier:body.identifier, body:body.body, sender:body.sender, thread_createdAt:thread_createdAt, title:thread_title}).exec(function createCB(err, created){
					if(err){
						return res.serverError(Response.failure(err, 500));
					} else{
						console.log(created);
					}
				})
			})
			return res.ok(Response.success(true));
		})

	},

};

